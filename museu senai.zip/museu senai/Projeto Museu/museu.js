const imagem = document.getElementById("imagem");


const carrossel = ['imagens/img1.jpg', 'imagens/img2.webp', 'imagens/img3.webp'];
let indice = 0;

function mudar(novo){
    indice = novo;
    imagem.src = carrossel[indice];
}

function proximo(){
    mudar((indice + 1) % carrossel.length);
}

function anterior (){
    mudar((indice - 1 + carrossel.length) % carrossel.length);
}